package com.example.kidsquiz;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class HomePage extends AppCompatActivity {

    TextView score;
    ImageButton drawMenu;
    LinearLayout add, sub, mul, div, anime, spin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_home_page);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        score = findViewById(R.id.score);
        add = findViewById(R.id.add);
        sub = findViewById(R.id.sub);
        mul = findViewById(R.id.mul);
        div = findViewById(R.id.div);
        anime = findViewById(R.id.anime);
        spin = findViewById(R.id.spin);
        drawMenu = findViewById(R.id.drawMenu);


        add.setOnClickListener(view -> {
            Intent intent = new Intent(HomePage.this, AdditionActivity.class);
            startActivity(intent);
            Toast.makeText(HomePage.this, "Loading Addition Activity", Toast.LENGTH_SHORT).show();
        });

        sub.setOnClickListener(view -> {
            Intent intent = new Intent(HomePage.this, SubtractionActivity.class);
            startActivity(intent);
            Toast.makeText(HomePage.this, "Loading Subtraction Activity", Toast.LENGTH_SHORT).show();
        });

        mul.setOnClickListener(view -> {
            Intent intent = new Intent(HomePage.this, MultiplyActivity.class);
            startActivity(intent);
            Toast.makeText(HomePage.this, "Loading Multiplication Activity", Toast.LENGTH_SHORT).show();
        });

        div.setOnClickListener(view -> {
            Intent intent = new Intent(HomePage.this, DivideActivity.class);
            startActivity(intent);
            Toast.makeText(HomePage.this, "Loading Division Activity", Toast.LENGTH_SHORT).show();
        });

        anime.setOnClickListener(view -> {
            Intent intent = new Intent(HomePage.this, AnimationActivity.class);
            startActivity(intent);
            Toast.makeText(HomePage.this, "Loading Animation Activity", Toast.LENGTH_SHORT).show();
        });

        spin.setOnClickListener(view -> {
            Intent intent = new Intent(HomePage.this, SpinActivity.class);
            startActivity(intent);
            Toast.makeText(HomePage.this, "Loading Spin Activity", Toast.LENGTH_SHORT).show();
        });

    }
}